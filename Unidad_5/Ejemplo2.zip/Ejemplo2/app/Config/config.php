<?php 
define("DIRBASEURL", "");
define("DIRPUBLIC", "")
?>