<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <h1>10 números pares</h1>
    <p>
        <?php 
            echo $data["message"]
        ?>
    </p>
</body>
</html>